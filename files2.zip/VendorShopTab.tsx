"use client";
// ─────────────────────────────────────────────────────────────────
// VendorShopTab — drop into vendor/dashboard/page.tsx as a tab
// Usage: import VendorShopTab from "./VendorShopTab"
//        Add { id: "shop", label: "Shop Listings", icon: ShoppingBag }
//        to SIDEBAR_ITEMS, then render <VendorShopTab vendorId={vendorId} />
// ─────────────────────────────────────────────────────────────────
import { useState, useEffect } from "react";
import {
  Plus, Edit, Trash2, Eye, MessageCircle, Heart, Crown, Zap, Check,
  Shield, Flame, AlertTriangle, CheckCircle2, Clock, X, ChevronDown,
  Tag, MapPin, ShoppingBag, TrendingUp, Megaphone,
} from "lucide-react";

const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:9000";

const PLANS: Record<string, { label: string; color: string; icon: any }> = {
  TOP:   { label: "Top",   color: "#D4AF37", icon: Crown },
  PRO:   { label: "Pro",   color: "#6366f1", icon: Zap   },
  BASIC: { label: "Basic", color: "#22c55e", icon: Check },
  LITE:  { label: "Lite",  color: "#94a3b8", icon: null  },
};

const STATUS_STYLES: Record<string, { bg: string; text: string; label: string; icon: any }> = {
  pending:  { bg: "bg-yellow-50",  text: "text-yellow-700",  label: "Pending Review", icon: Clock         },
  active:   { bg: "bg-green-50",   text: "text-green-700",   label: "Live",           icon: CheckCircle2  },
  rejected: { bg: "bg-red-50",     text: "text-red-700",     label: "Rejected",       icon: X             },
  paused:   { bg: "bg-gray-50",    text: "text-gray-600",    label: "Paused",         icon: Clock         },
  expired:  { bg: "bg-orange-50",  text: "text-orange-700",  label: "Expired",        icon: AlertTriangle },
};

const CITIES = ["Cairo", "Alexandria", "Giza", "Hurghada", "Sharm El Sheikh", "Luxor", "Aswan"];

const inp = "w-full px-3 py-2.5 rounded-xl border border-gray-200 text-xs outline-none focus:border-pink-300 focus:ring-2 focus:ring-pink-50 transition bg-white";
const lbl = "block text-[10px] font-bold text-gray-500 mb-1 uppercase tracking-wide";

interface Product {
  id: string; name: string; description?: string;
  category_id: string; category_name?: string; category_color?: string;
  subcategory_id?: string; subcategory_name?: string;
  price: string; price_original?: string; currency: string;
  city?: string; plan_type: string; status: string;
  is_featured: boolean; is_verified: boolean; is_active: boolean;
  cover_image?: string; images: string[];
  view_count: number; inquiry_count: number; save_count: number;
  rejection_reason?: string; created_at: string;
}

interface Category {
  id: string; name: string; color: string;
  subcategories?: { id: string; name: string }[];
}

interface Quota {
  allowed: boolean; used: number; limit: number; plan: string; message?: string;
}

function ProductForm({
  categories, vendorId, product, onSave, onCancel,
}: {
  categories: Category[]; vendorId: string;
  product?: Product | null; onSave: (p: Product) => void; onCancel: () => void;
}) {
  const [form, setForm] = useState({
    name:          product?.name          || "",
    description:   product?.description  || "",
    category_id:   product?.category_id  || "",
    subcategory_id:product?.subcategory_id|| "",
    price:         product?.price         || "",
    price_original:product?.price_original|| "",
    currency:      product?.currency      || "EGP",
    city:          product?.city          || "",
    cover_image:   product?.cover_image   || "",
    plan_type:     product?.plan_type     || "LITE",
    tags:          product?.tags?.join(", ") || "",
  });
  const [saving,  setSaving]  = useState(false);
  const [error,   setError]   = useState("");

  const selectedCat = categories.find(c => c.id === form.category_id);

  async function handleSubmit() {
    if (!form.name.trim())      { setError("Product name is required."); return; }
    if (!form.category_id)      { setError("Please select a category."); return; }
    if (!form.price)            { setError("Price is required."); return; }
    setError(""); setSaving(true);

    const payload = {
      ...form,
      price:         parseFloat(form.price),
      price_original: form.price_original ? parseFloat(form.price_original) : null,
      tags:          form.tags.split(",").map((t: string) => t.trim()).filter(Boolean),
      images:        form.cover_image ? [form.cover_image] : [],
    };

    try {
      const url    = product
        ? `${API}/api/shop/vendor/${vendorId}/products/${product.id}`
        : `${API}/api/shop/vendor/${vendorId}/products`;
      const method = product ? "PUT" : "POST";
      const res    = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      const data   = await res.json();
      if (data.success) { onSave(data.data); }
      else if (data.upgrade_required) {
        setError(data.error || "Quota exceeded. Please upgrade your plan.");
      } else {
        setError(data.error || "Failed to save listing.");
      }
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto shadow-2xl">
        <div className="sticky top-0 bg-white px-6 py-4 border-b border-gray-100 flex items-center justify-between">
          <h3 className="font-bold text-gray-900 text-sm">{product ? "Edit Listing" : "New Shop Listing"}</h3>
          <button onClick={onCancel} className="w-7 h-7 rounded-full bg-gray-100 flex items-center justify-center text-gray-500 hover:bg-gray-200 transition">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          {/* Name */}
          <div>
            <label className={lbl}>Product / Listing Name *</label>
            <input className={inp} value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="e.g. Ivory Lace Wedding Dress" />
          </div>

          {/* Category */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className={lbl}>Category *</label>
              <select className={inp} value={form.category_id} onChange={e => setForm(f => ({ ...f, category_id: e.target.value, subcategory_id: "" }))}>
                <option value="">Select category</option>
                {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className={lbl}>Subcategory</label>
              <select className={inp} value={form.subcategory_id} onChange={e => setForm(f => ({ ...f, subcategory_id: e.target.value }))}>
                <option value="">Select subcategory</option>
                {selectedCat?.subcategories?.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </div>
          </div>

          {/* Price */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className={lbl}>Price (EGP) *</label>
              <input className={inp} type="number" value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))} placeholder="0" />
            </div>
            <div>
              <label className={lbl}>Original Price (optional)</label>
              <input className={inp} type="number" value={form.price_original} onChange={e => setForm(f => ({ ...f, price_original: e.target.value }))} placeholder="For discount display" />
            </div>
          </div>

          {/* City */}
          <div>
            <label className={lbl}>City</label>
            <select className={inp} value={form.city} onChange={e => setForm(f => ({ ...f, city: e.target.value }))}>
              <option value="">Select city</option>
              {CITIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>

          {/* Description */}
          <div>
            <label className={lbl}>Description</label>
            <textarea className={inp} rows={3} value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="Describe your product..." />
          </div>

          {/* Cover Image URL */}
          <div>
            <label className={lbl}>Cover Image URL</label>
            <input className={inp} value={form.cover_image} onChange={e => setForm(f => ({ ...f, cover_image: e.target.value }))} placeholder="https://..." />
            {form.cover_image && (
              <img src={form.cover_image} alt="" className="mt-2 h-20 w-full object-cover rounded-xl border border-gray-100" onError={e => (e.currentTarget.style.display = 'none')} />
            )}
          </div>

          {/* Tags */}
          <div>
            <label className={lbl}>Tags (comma separated)</label>
            <input className={inp} value={form.tags} onChange={e => setForm(f => ({ ...f, tags: e.target.value }))} placeholder="e.g. lace, ivory, custom" />
          </div>

          {/* Plan type */}
          <div>
            <label className={lbl}>Listing Plan</label>
            <select className={inp} value={form.plan_type} onChange={e => setForm(f => ({ ...f, plan_type: e.target.value }))}>
              <option value="LITE">Lite (Free)</option>
              <option value="BASIC">Basic — EGP 299/mo</option>
              <option value="PRO">Pro — EGP 699/mo</option>
              <option value="TOP">Top — EGP 1,299/mo</option>
            </select>
            <p className="text-[10px] text-gray-400 mt-1">Higher plans get priority placement and featured badge.</p>
          </div>

          {error && (
            <div className="flex items-start gap-2 bg-red-50 border border-red-100 rounded-xl p-3 text-xs text-red-700">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />{error}
            </div>
          )}

          <div className="flex gap-2 pt-2">
            <button onClick={handleSubmit} disabled={saving}
              className="flex-1 py-2.5 rounded-xl text-white text-xs font-bold transition disabled:opacity-60"
              style={{ background: "linear-gradient(135deg,#FE6972,#c9485f)" }}>
              {saving ? "Saving..." : product ? "Save Changes" : "Submit for Review"}
            </button>
            <button onClick={onCancel} className="px-4 py-2.5 rounded-xl border border-gray-200 text-xs text-gray-600 font-semibold hover:bg-gray-50 transition">
              Cancel
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function VendorShopTab({ vendorId }: { vendorId: string }) {
  const [products,   setProducts]   = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [quota,      setQuota]      = useState<Quota | null>(null);
  const [inquiries,  setInquiries]  = useState<any[]>([]);
  const [loading,    setLoading]    = useState(true);
  const [showForm,   setShowForm]   = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [activeSubTab, setActiveSubTab] = useState<"listings"|"inquiries"|"plans">("listings");

  useEffect(() => {
    if (!vendorId) return;
    Promise.all([
      fetch(`${API}/api/shop/vendor/${vendorId}/products`).then(r => r.json()),
      fetch(`${API}/api/shop/categories?includeSubcategories=true`).then(r => r.json()),
      fetch(`${API}/api/shop/vendor/${vendorId}/inquiries`).then(r => r.json()),
    ]).then(([prod, cats, inq]) => {
      if (prod.success) { setProducts(prod.data || []); setQuota(prod.quota); }
      if (cats.success) setCategories(cats.data || []);
      if (inq.success)  setInquiries(inq.data || []);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [vendorId]);

  async function handleDelete(id: string) {
    if (!confirm("Delete this listing?")) return;
    await fetch(`${API}/api/shop/vendor/${vendorId}/products/${id}`, { method: "DELETE" });
    setProducts(prev => prev.filter(p => p.id !== id));
  }

  function handleSaved(product: Product) {
    setProducts(prev => {
      const exists = prev.find(p => p.id === product.id);
      return exists ? prev.map(p => p.id === product.id ? product : p) : [product, ...prev];
    });
    setShowForm(false);
    setEditingProduct(null);
  }

  const newInquiries = inquiries.filter(i => i.status === "new").length;

  if (loading) return (
    <div className="flex items-center justify-center py-20">
      <div className="animate-pulse text-center">
        <ShoppingBag className="w-8 h-8 text-gray-200 mx-auto mb-2" />
        <p className="text-xs text-gray-400">Loading shop...</p>
      </div>
    </div>
  );

  return (
    <div className="p-4 max-w-4xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="font-bold text-gray-900 text-sm flex items-center gap-2">
            <ShoppingBag className="w-4 h-4 text-[#FE6972]" />Shop Listings
          </h2>
          <p className="text-[11px] text-gray-400 mt-0.5">Manage your product advertisements</p>
        </div>
        <button
          onClick={() => { setEditingProduct(null); setShowForm(true); }}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-white text-xs font-bold transition"
          style={{ background: "linear-gradient(135deg,#FE6972,#c9485f)" }}
        >
          <Plus className="w-3.5 h-3.5" />New Listing
        </button>
      </div>

      {/* Quota bar */}
      {quota && (
        <div className={`rounded-xl p-3 mb-4 flex items-center gap-3 ${quota.allowed ? "bg-green-50 border border-green-100" : "bg-red-50 border border-red-100"}`}>
          <div className="flex-1">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[11px] font-bold text-gray-700">
                {quota.plan?.toUpperCase()} Plan — {quota.used} / {quota.limit === -1 ? "∞" : quota.limit} listings used this month
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full"
                style={{ background: quota.allowed ? "#dcfce7" : "#fee2e2", color: quota.allowed ? "#166534" : "#991b1b" }}>
                {quota.allowed ? "✓ Quota OK" : "⚠ Limit Reached"}
              </span>
            </div>
            {quota.limit !== -1 && (
              <div className="h-1.5 bg-gray-200 rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all"
                  style={{ width: `${Math.min((quota.used / quota.limit) * 100, 100)}%`, background: quota.allowed ? "#22c55e" : "#ef4444" }} />
              </div>
            )}
            {!quota.allowed && <p className="text-[10px] text-red-600 mt-1">{quota.message}</p>}
          </div>
          {!quota.allowed && (
            <button className="shrink-0 px-3 py-1.5 rounded-lg text-[11px] font-bold text-white"
              style={{ background: "#D4AF37" }}
              onClick={() => setActiveSubTab("plans")}>
              Upgrade Plan
            </button>
          )}
        </div>
      )}

      {/* Sub tabs */}
      <div className="flex gap-1 mb-4 bg-gray-50 p-1 rounded-xl w-fit">
        {[
          { id: "listings",  label: `Listings (${products.length})`    },
          { id: "inquiries", label: `Inquiries${newInquiries > 0 ? ` (${newInquiries} new)` : ""}` },
          { id: "plans",     label: "Plans & Pricing"                   },
        ].map(t => (
          <button key={t.id} onClick={() => setActiveSubTab(t.id as any)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${activeSubTab === t.id ? "bg-white text-gray-900 shadow-sm" : "text-gray-500"}`}>
            {t.label}
          </button>
        ))}
      </div>

      {/* LISTINGS TAB */}
      {activeSubTab === "listings" && (
        <div className="space-y-3">
          {products.length === 0 ? (
            <div className="text-center py-12 bg-gray-50 rounded-2xl">
              <ShoppingBag className="w-10 h-10 text-gray-200 mx-auto mb-3" />
              <p className="text-sm font-semibold text-gray-500 mb-1">No listings yet</p>
              <p className="text-xs text-gray-400 mb-4">Create your first product listing to start getting inquiries.</p>
              <button onClick={() => setShowForm(true)}
                className="px-4 py-2 rounded-xl text-white text-xs font-bold"
                style={{ background: "#FE6972" }}>
                + Create First Listing
              </button>
            </div>
          ) : (
            products.map(p => {
              const plan   = PLANS[p.plan_type] || PLANS.LITE;
              const PlanIcon = plan.icon;
              const status = STATUS_STYLES[p.status] || STATUS_STYLES.pending;
              const StatusIcon = status.icon;
              return (
                <div key={p.id} className="bg-white rounded-xl border border-gray-100 p-3 flex gap-3">
                  {/* Image */}
                  <div className="w-16 h-16 rounded-xl overflow-hidden shrink-0 bg-gray-100">
                    {p.cover_image
                      ? <img src={p.cover_image} alt={p.name} className="w-full h-full object-cover" />
                      : <div className="w-full h-full flex items-center justify-center"><ShoppingBag className="w-6 h-6 text-gray-300" /></div>
                    }
                  </div>
                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <h4 className="font-bold text-gray-900 text-xs line-clamp-1">{p.name}</h4>
                        <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                          {p.category_name && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded-full"
                              style={{ background: `${p.category_color}20`, color: p.category_color || "#FE6972" }}>
                              {p.category_name}
                            </span>
                          )}
                          {p.city && (
                            <span className="text-[10px] text-gray-400 flex items-center gap-0.5">
                              <MapPin className="w-2.5 h-2.5" />{p.city}
                            </span>
                          )}
                        </div>
                      </div>
                      {/* Status badge */}
                      <span className={`shrink-0 flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${status.bg} ${status.text}`}>
                        <StatusIcon className="w-2.5 h-2.5" />{status.label}
                      </span>
                    </div>
                    {/* Rejection reason */}
                    {p.status === 'rejected' && p.rejection_reason && (
                      <p className="text-[10px] text-red-500 mt-1 bg-red-50 px-2 py-1 rounded-lg">
                        Reason: {p.rejection_reason}
                      </p>
                    )}
                    {/* Stats + plan */}
                    <div className="flex items-center gap-3 mt-2 flex-wrap">
                      <span className="text-xs font-bold text-gray-900">{parseFloat(p.price).toLocaleString()} EGP</span>
                      {PlanIcon && (
                        <span className="flex items-center gap-0.5 text-[10px] font-bold px-1.5 py-0.5 rounded-full text-white"
                          style={{ background: plan.color }}>
                          <PlanIcon className="w-2.5 h-2.5" />{plan.label}
                        </span>
                      )}
                      <span className="flex items-center gap-0.5 text-[10px] text-gray-400"><Eye className="w-3 h-3" />{p.view_count}</span>
                      <span className="flex items-center gap-0.5 text-[10px] text-gray-400"><MessageCircle className="w-3 h-3" />{p.inquiry_count}</span>
                      <span className="flex items-center gap-0.5 text-[10px] text-gray-400"><Heart className="w-3 h-3" />{p.save_count}</span>
                    </div>
                  </div>
                  {/* Actions */}
                  <div className="flex flex-col gap-1.5 shrink-0">
                    <button onClick={() => { setEditingProduct(p); setShowForm(true); }}
                      className="w-7 h-7 rounded-lg bg-gray-50 hover:bg-gray-100 flex items-center justify-center transition">
                      <Edit className="w-3.5 h-3.5 text-gray-500" />
                    </button>
                    <button onClick={() => handleDelete(p.id)}
                      className="w-7 h-7 rounded-lg bg-red-50 hover:bg-red-100 flex items-center justify-center transition">
                      <Trash2 className="w-3.5 h-3.5 text-red-500" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* INQUIRIES TAB */}
      {activeSubTab === "inquiries" && (
        <div className="space-y-2">
          {inquiries.length === 0 ? (
            <div className="text-center py-12 bg-gray-50 rounded-2xl">
              <MessageCircle className="w-10 h-10 text-gray-200 mx-auto mb-3" />
              <p className="text-sm font-semibold text-gray-500">No inquiries yet</p>
              <p className="text-xs text-gray-400">Inquiries from customers will appear here.</p>
            </div>
          ) : (
            inquiries.map(inq => (
              <div key={inq.id} className={`bg-white rounded-xl border p-3 ${inq.status === 'new' ? 'border-[#FE6972]/30 bg-pink-50/30' : 'border-gray-100'}`}>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-xs text-gray-900">{inq.name}</span>
                      {inq.status === 'new' && (
                        <span className="text-[9px] font-bold bg-[#FE6972] text-white px-1.5 py-0.5 rounded-full">NEW</span>
                      )}
                    </div>
                    <p className="text-[10px] text-gray-400 mt-0.5">
                      {inq.product_name} · {new Date(inq.created_at).toLocaleDateString()}
                    </p>
                    {inq.message && <p className="text-xs text-gray-600 mt-1.5 bg-gray-50 rounded-lg px-2 py-1.5">{inq.message}</p>}
                  </div>
                  <div className="flex flex-col gap-1 shrink-0 text-right">
                    {inq.phone && <a href={`tel:${inq.phone}`} className="text-[10px] text-blue-600 font-semibold">{inq.phone}</a>}
                    {inq.email && <a href={`mailto:${inq.email}`} className="text-[10px] text-blue-600 font-semibold">{inq.email}</a>}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* PLANS TAB */}
      {activeSubTab === "plans" && (
        <div className="space-y-3">
          <div className="bg-gradient-to-r from-pink-50 to-rose-50 rounded-xl p-4 border border-pink-100 mb-4">
            <h3 className="font-bold text-gray-900 text-sm flex items-center gap-2 mb-1">
              <Megaphone className="w-4 h-4 text-[#FE6972]" />Advertising Plans
            </h3>
            <p className="text-xs text-gray-500">Your first 3 listings per month are free. Upgrade for more listings, priority placement, and featured badges.</p>
          </div>
          {[
            { id: "LITE",  name: "Lite",  price: "Free",    period: "",    color: "#94a3b8", features: ["3 free listings/month", "Standard placement", "Contact form"],            limit: "3/month" },
            { id: "BASIC", name: "Basic", price: "299",     period: "/mo", color: "#22c55e", features: ["1 active listing", "Standard placement", "3 photos", "City targeting"],  limit: "1 active" },
            { id: "PRO",   name: "Pro",   price: "699",     period: "/mo", color: "#6366f1", features: ["3 active listings", "Priority placement", "8 photos", "Featured badge", "Analytics"], limit: "3 active", popular: true },
            { id: "TOP",   name: "Top",   price: "1,299",   period: "/mo", color: "#D4AF37", features: ["Unlimited listings", "Top placement", "20 photos", "Featured + Verified", "Homepage spotlight"], limit: "Unlimited" },
          ].map(plan => (
            <div key={plan.id}
              className={`bg-white rounded-xl border p-4 relative ${(plan as any).popular ? "border-[#FE6972]" : "border-gray-200"} ${quota?.plan?.toUpperCase() === plan.id ? "ring-2 ring-[#FE6972]/30" : ""}`}>
              {(plan as any).popular && (
                <span className="absolute -top-2.5 right-4 bg-[#FE6972] text-white text-[9px] font-bold px-2 py-0.5 rounded-full">POPULAR</span>
              )}
              {quota?.plan?.toUpperCase() === plan.id && (
                <span className="absolute -top-2.5 left-4 bg-gray-900 text-white text-[9px] font-bold px-2 py-0.5 rounded-full">CURRENT PLAN</span>
              )}
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full" style={{ background: plan.color }} />
                  <span className="font-bold text-sm text-gray-900">{plan.name}</span>
                  <span className="text-[10px] bg-gray-100 text-gray-500 px-1.5 py-0.5 rounded-full">{plan.limit}</span>
                </div>
                <span className="font-black text-base" style={{ color: plan.color }}>
                  {plan.price === "Free" ? "Free" : `EGP ${plan.price}`}
                  <span className="text-xs font-normal text-gray-400">{plan.period}</span>
                </span>
              </div>
              <div className="flex flex-wrap gap-1.5 mb-3">
                {plan.features.map(f => (
                  <span key={f} className="text-[10px] bg-gray-50 text-gray-500 px-2 py-0.5 rounded-full">✓ {f}</span>
                ))}
              </div>
              {quota?.plan?.toUpperCase() !== plan.id && plan.id !== "LITE" && (
                <button
                  onClick={async () => {
                    const res = await fetch(`${API}/api/shop/vendor/${vendorId}/upgrade-plan`, {
                      method: "POST", headers: { "Content-Type": "application/json" },
                      body: JSON.stringify({ plan: plan.id }),
                    });
                    const data = await res.json();
                    if (data.success) {
                      alert(`Upgraded to ${plan.name}! In production this would trigger payment.`);
                      // Refresh quota
                      fetch(`${API}/api/shop/vendor/${vendorId}/quota`).then(r => r.json()).then(d => { if (d.success) setQuota(d.data); });
                    }
                  }}
                  className="w-full py-2 rounded-xl text-white text-xs font-bold transition"
                  style={{ background: plan.color }}>
                  Upgrade to {plan.name}
                </button>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Product Form Modal */}
      {showForm && (
        <ProductForm
          categories={categories}
          vendorId={vendorId}
          product={editingProduct}
          onSave={handleSaved}
          onCancel={() => { setShowForm(false); setEditingProduct(null); }}
        />
      )}
    </div>
  );
}
